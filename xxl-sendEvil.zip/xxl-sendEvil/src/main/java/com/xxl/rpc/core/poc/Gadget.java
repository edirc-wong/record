package com.xxl.rpc.core.poc;

/**
 * @author mbechler
 *
 */
public interface Gadget {

}
